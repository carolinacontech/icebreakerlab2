"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useMemo, useState } from "react";
import styles from "./InteractiveIceHero.module.css";

type Burst = { id: number; stage: number; seed: number };

type ShardDef = {
  id: string;
  clip: string;
  left: string;
  top: string;
  width: string;
  height: string;
  dx: number;
  dy: number;
  rotate: number;
  delay: number;
  depth: number;
};

const crackPrimary = [
  "M306 212 C 298 247, 294 278, 278 323",
  "M282 317 C 265 341, 247 361, 236 394",
  "M274 278 C 248 292, 221 313, 205 338",
];

const crackSecondary = [
  "M291 236 C 318 247, 333 264, 354 288",
  "M248 300 C 229 288, 212 281, 184 274",
  "M237 386 C 252 406, 264 430, 268 458",
  "M208 338 C 180 349, 162 366, 145 392",
  "M328 274 C 346 263, 372 255, 394 253",
];

const shards: ShardDef[] = [
  { id: "s1", clip: "polygon(50% 0, 74% 19%, 61% 37%, 42% 34%)", left: "41%", top: "12%", width: "13%", height: "17%", dx: 2, dy: -2, rotate: 4, delay: 0.0, depth: 1 },
  { id: "s2", clip: "polygon(0 19%, 50% 0, 42% 34%, 18% 50%)", left: "33.4%", top: "12%", width: "11%", height: "20%", dx: -14, dy: -10, rotate: -18, delay: 0.02, depth: 1 },
  { id: "s3", clip: "polygon(74% 19%, 100% 48%, 70% 58%, 61% 37%)", left: "49.7%", top: "14.2%", width: "14%", height: "20%", dx: 28, dy: 0, rotate: 21, delay: 0.04, depth: 2 },
  { id: "s4", clip: "polygon(18% 50%, 42% 34%, 39% 57%, 0 63%)", left: "31%", top: "24.5%", width: "13.5%", height: "16%", dx: -26, dy: 8, rotate: -23, delay: 0.07, depth: 1 },
  { id: "s5", clip: "polygon(42% 34%, 61% 37%, 57% 56%, 39% 57%)", left: "41.6%", top: "22.2%", width: "12.6%", height: "17%", dx: 4, dy: 14, rotate: 9, delay: 0.05, depth: 3 },
  { id: "s6", clip: "polygon(61% 37%, 70% 58%, 57% 56%)", left: "51.2%", top: "23.8%", width: "10%", height: "15%", dx: 20, dy: 15, rotate: 13, delay: 0.09, depth: 1 },
  { id: "s7", clip: "polygon(0 63%, 39% 57%, 31% 77%, 9% 80%)", left: "29.4%", top: "34.8%", width: "15%", height: "18.5%", dx: -30, dy: 24, rotate: -30, delay: 0.1, depth: 1 },
  { id: "s8", clip: "polygon(39% 57%, 57% 56%, 52% 77%, 31% 77%)", left: "40.3%", top: "35.2%", width: "14%", height: "19%", dx: -3, dy: 26, rotate: 7, delay: 0.12, depth: 2 },
  { id: "s9", clip: "polygon(57% 56%, 70% 58%, 80% 78%, 52% 77%)", left: "49.8%", top: "35.2%", width: "15%", height: "20%", dx: 26, dy: 28, rotate: 24, delay: 0.13, depth: 1 },
  { id: "s10", clip: "polygon(9% 80%, 31% 77%, 28% 100%, 0 92%)", left: "28.8%", top: "48.8%", width: "13.2%", height: "21%", dx: -35, dy: 47, rotate: -35, delay: 0.16, depth: 1 },
  { id: "s11", clip: "polygon(31% 77%, 52% 77%, 50% 100%, 28% 100%)", left: "40.3%", top: "49%", width: "12.8%", height: "21%", dx: 2, dy: 50, rotate: 10, delay: 0.18, depth: 2 },
  { id: "s12", clip: "polygon(52% 77%, 80% 78%, 100% 91%, 50% 100%)", left: "50.4%", top: "48.8%", width: "18%", height: "22%", dx: 36, dy: 44, rotate: 33, delay: 0.14, depth: 3 },
];

function BurstParticles({ burst }: { burst: Burst }) {
  const particles = useMemo(() => {
    const count = burst.stage === 1 ? 24 : burst.stage === 2 ? 44 : 96;
    const out = [] as Array<{
      id: number;
      left: string;
      top: string;
      size: number;
      dx: number;
      dy: number;
      rotate: number;
      delay: number;
      duration: number;
      glow: boolean;
      color: string;
    }>;

    for (let i = 0; i < count; i++) {
      const angle = ((i * 137.5 + burst.seed * 19) % 360) * (Math.PI / 180);
      const spread = burst.stage === 1 ? 36 : burst.stage === 2 ? 72 : 180;
      const speed = burst.stage === 1 ? 26 : burst.stage === 2 ? 48 : 88;
      const randomness = ((i * 73 + burst.seed * 11) % 100) / 100;
      const dist = speed + randomness * spread;
      out.push({
        id: i,
        left: `calc(50% + ${Math.cos(angle) * (burst.stage === 3 ? 6 : 0)}px)`,
        top: `calc(42% + ${Math.sin(angle) * (burst.stage === 3 ? 6 : 0)}px)`,
        size: burst.stage === 3 ? 2 + randomness * 6 : 1 + randomness * 3.4,
        dx: Math.cos(angle) * dist,
        dy: Math.sin(angle) * dist - (burst.stage === 3 ? 18 : 6),
        rotate: randomness * 180,
        delay: (i % 7) * 0.012,
        duration: burst.stage === 3 ? 1.25 + randomness * 0.7 : 0.7 + randomness * 0.35,
        glow: i % (burst.stage === 3 ? 3 : 5) === 0,
        color: i % 3 === 0 ? "rgba(157, 232, 207, 0.95)" : i % 2 === 0 ? "rgba(166, 221, 255, 0.92)" : "rgba(226, 244, 255, 0.88)",
      });
    }
    return out;
  }, [burst]);

  return (
    <div className={styles.particleBurst} aria-hidden="true">
      {particles.map((particle) => (
        <motion.span
          key={`${burst.id}-${particle.id}`}
          className={`${styles.particle} ${particle.glow ? styles.particleGlow : ""}`}
          initial={{ opacity: 0, x: 0, y: 0, scale: 0.4, rotate: 0 }}
          animate={{
            opacity: [0, 1, 0],
            x: [0, particle.dx],
            y: [0, particle.dy],
            scale: [0.5, 1, 0.45],
            rotate: [0, particle.rotate],
          }}
          transition={{
            duration: particle.duration,
            delay: particle.delay,
            ease: [0.16, 1, 0.3, 1],
          }}
          style={{
            left: particle.left,
            top: particle.top,
            width: particle.size,
            height: particle.size,
            background: particle.color,
          }}
        />
      ))}
    </div>
  );
}

function CrackStage({ stage }: { stage: number }) {
  return (
    <svg className={styles.crackOverlay} viewBox="0 0 500 700" aria-hidden="true">
      {crackPrimary.map((path, i) => (
        <motion.path
          key={`primary-${i}`}
          d={path}
          initial={false}
          animate={{
            pathLength: stage >= 1 ? 1 : 0,
            opacity: stage >= 1 ? 0.95 : 0,
          }}
          transition={{ duration: 0.45, delay: i * 0.07, ease: [0.25, 1, 0.5, 1] }}
          className={styles.crackLine}
        />
      ))}
      {crackSecondary.map((path, i) => (
        <motion.path
          key={`secondary-${i}`}
          d={path}
          initial={false}
          animate={{
            pathLength: stage >= 2 ? 1 : 0,
            opacity: stage >= 2 ? 0.92 : 0,
          }}
          transition={{ duration: 0.45, delay: 0.1 + i * 0.06, ease: [0.25, 1, 0.5, 1] }}
          className={`${styles.crackLine} ${styles.crackLineSecondary}`}
        />
      ))}
      {[...crackPrimary, ...crackSecondary].map((path, i) => (
        <motion.path
          key={`glow-${i}`}
          d={path}
          initial={false}
          animate={{
            pathLength: stage >= 1 ? 1 : 0,
            opacity: stage >= 1 ? (stage >= 2 ? 0.55 : 0.35) : 0,
          }}
          transition={{ duration: 0.6, delay: i * 0.03 }}
          className={styles.crackGlow}
        />
      ))}
    </svg>
  );
}

export default function InteractiveIceHero() {
  const reduceMotion = useReducedMotion();
  const [stage, setStage] = useState(0);
  const [bursts, setBursts] = useState<Burst[]>([]);

  const triggerStage = () => {
    if (stage >= 3) {
      setStage(0);
      return;
    }
    const next = stage + 1;
    setStage(next);
    setBursts((prev) => [...prev, { id: Date.now() + next, stage: next, seed: prev.length + 1 }]);
    window.setTimeout(() => {
      setBursts((prev) => prev.slice(-4));
    }, 2200);
  };

  return (
    <section className={styles.hero} id="top">
      <div className={styles.backdrop} aria-hidden="true" />
      <div className={styles.noise} aria-hidden="true" />
      <div className={styles.glowLeft} aria-hidden="true" />
      <div className={styles.glowRight} aria-hidden="true" />

      <div className={styles.inner}>
        <div className={styles.copy}>
          <div className={styles.eyebrow}>
            <span className={styles.dot} />
            WEB DESIGN STUDIO <span>·</span> SEO <span>·</span> STRATEGY
          </div>

          <h1 className={styles.title}>
            We build websites
            <span>that break the ice.</span>
          </h1>

          <p className={styles.body}>
            Beautiful on the surface. Strategic underneath. Click the iceberg and
            watch the pressure build with cracks, fragments and flying ice dust.
          </p>

          <div className={styles.actions}>
            <a href="#contact" className={styles.primaryBtn}>Start a project ↗</a>
            <a href="#portfolio" className={styles.secondaryBtn}>Explore our work →</a>
          </div>

          <div className={styles.statusRow}>
            <span className={styles.counter}>0{stage} / 03</span>
            <span className={styles.statusText}>
              {stage === 0 && "CLICK THE ICEBERG TO START THE FRACTURE"}
              {stage === 1 && "PRESSURE BUILDING — MORE CRACKS, SMALLER FRAGMENTS"}
              {stage === 2 && "THE ICE IS GIVING WAY — ONE MORE CLICK"}
              {stage === 3 && "THE ICE IS BROKEN — CLICK AGAIN TO REBUILD"}
            </span>
          </div>
        </div>

        <div className={styles.visualWrap}>
          <button
            type="button"
            className={`${styles.iceButton} ${stage === 3 ? styles.iceButtonBroken : ""}`}
            onClick={triggerStage}
            aria-label={stage === 3 ? "Rebuild the iceberg" : `Break the iceberg, stage ${stage + 1} of 3`}
          >
            <div className={styles.iceScene}>
              <div className={styles.waterline} aria-hidden="true" />
              <AnimatePresence>
                {stage < 3 && (
                  <motion.div
                    key={`core-${stage}`}
                    className={`${styles.icebergCore} ${stage >= 1 ? styles.stageOne : ""} ${stage >= 2 ? styles.stageTwo : ""}`}
                    initial={{ opacity: 0.96, scale: 1 }}
                    animate={{
                      opacity: 1,
                      scale: stage >= 2 ? 0.992 : 1,
                      rotate: stage === 0 ? 0 : stage === 1 ? -1.2 : 1.4,
                      x: stage === 2 ? -4 : 0,
                      y: stage === 2 ? 2 : 0,
                    }}
                    exit={{ opacity: 0, scale: 1.03 }}
                    transition={{ duration: 0.55, ease: [0.2, 1, 0.32, 1] }}
                  >
                    <div className={styles.icebergGlow} aria-hidden="true" />
                    <div className={styles.icebergTexture} aria-hidden="true" />
                    <div className={styles.icebergHighlight} aria-hidden="true" />
                    <CrackStage stage={stage} />
                    {stage >= 1 && <div className={`${styles.impactDust} ${stage >= 2 ? styles.impactDustLarge : ""}`} aria-hidden="true" />}
                  </motion.div>
                )}
              </AnimatePresence>

              <AnimatePresence>
                {stage === 3 && (
                  <>
                    {shards.map((shard) => (
                      <motion.div
                        key={shard.id}
                        className={styles.shard}
                        initial={{ opacity: 0, x: 0, y: 0, rotate: 0, scale: 1 }}
                        animate={{
                          opacity: 1,
                          x: reduceMotion ? 0 : shard.dx * 8,
                          y: reduceMotion ? 0 : shard.dy * 6,
                          rotate: reduceMotion ? 0 : shard.rotate,
                          scale: 1,
                        }}
                        transition={{
                          duration: 1.2,
                          delay: shard.delay,
                          ease: [0.16, 1, 0.3, 1],
                        }}
                        style={{
                          left: shard.left,
                          top: shard.top,
                          width: shard.width,
                          height: shard.height,
                          clipPath: shard.clip,
                          zIndex: 10 + shard.depth,
                        }}
                      >
                        <div className={styles.shardTexture} />
                        <div className={styles.shardHighlight} />
                      </motion.div>
                    ))}
                  </>
                )}
              </AnimatePresence>
            </div>
          </button>

          <AnimatePresence>
            {bursts.map((burst) => (
              <BurstParticles key={burst.id} burst={burst} />
            ))}
          </AnimatePresence>
        </div>
      </div>

      <button
        type="button"
        className={styles.scrollCue}
        onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}
      >
        <span />
        SCROLL TO EXPLORE
      </button>
    </section>
  );
}
